<?php

include('header.php');
include('menu.php');
//connect to db
include('conn.php');

?>


<table border="1" cellpadding="2" cellspacing="2">
	<tr>
	<th>Bil.</th>
	<th>Nama</th>
	<th>Bhgn.</th>
	<th>Tel</th>
	<th>Email</th>
	<th>&nbsp;</th>
	</tr>
<?php
//query
$sql = "SELECT * FROM persons";
$result = mysql_query ($sql,$conn) or die (mysql_error ());
$i=1;
//mysql_fetch _array akan ambik result
while($row = mysql_fetch_array($result)) {
   echo "<tr>";
   echo "<td>$i.</td>";
   echo "<td>$row[Nama]&nbsp;</td>";
   echo "<td>$row[bhgn]&nbsp</td>";
   echo "<td>$row[phone]&nbsp</td>";
   echo "<td>$row[email]&nbsp</td>";
   echo "<td><a href=\"pinda.php?id=$row[id]\">Pinda</a>";
   echo '
			<form action="hapus.php" method="post">
				<input type="hidden" name="del_id" value="'.$row['id'].'"/>
				
				<input type="submit" value="Hapus"
				onclick="return confirm(\'Adakah anda pasti untuk hapus rekod ini?\')"/>
			</form>
			';
   echo "</td>";
   echo "</tr>";
   $i++;
	
  }
 ?>
 </table>
 <?php
include('footer.php');


?>