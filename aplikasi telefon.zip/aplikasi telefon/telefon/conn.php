<?php
//conn.php
// remember to connect to database
  $db_host = "localhost";
  $db_user = "root";
  $db_passwd = "";
  $db_name = "phone";
//connect mysql
 $conn = mysql_connect ($db_host, $db_user, $db_passwd);
 if ( $conn ){
	 // echo "Connected to db";
 }	 else {
		echo "Failed to connect db !";
		die ();
 }
	//select db
	$sel_db = mysql_select_db ($db_name, $conn);
	if( $sel_db ) {
		//echo " Succesfully select db ".$db_name;
	} else{
		echo "Failed to select db";
		die ();
	}
  
 ?>