
<?php

include('header.php');
include('menu.php');
?>

<h2>Registration Form</h2>

<form action="insert_new.php" method="post">
Name : <input type="text" name="inputNama" />
<br>
<br>
Destination : <input type="text" name="inputDestinasi" />
<br>
<br>
HandPhone Number : <input type="text" name="inputPhone" />
<br>
<br>
Email : <input type="text" name="inputEmail" />
<br>
<br>

<input type="submit" value="Register" />
</form>


<?php
include ('footer.php');

?>