<?php 

//TYPES OF ARRAY
//numeric array
$no_pers = array ("Haq", 
				  "Shahrom", 
				  "Zaini"
				  );
echo "<br />";
//or can write like this		  
$nama_pers[0] = "Haq";
$nama_pers[1] = "Shahrom";
$nama_pers[2] = "Zaini";

print_r($nama_pers);
echo "<br />";

//Associative array
$pers = array (
				"no_pers" => "123",
				"nama" => "Haq",
				"Jab" => "TSM"
				);

echo "<br />";
//or can write like this
$pers ["no_pers"] = "123";
$pers ["nama"] = "Haq";
$pers ["Jab"] = "TSM";

print_r($pers);

echo "<br />";
//Multidimentional Array

$multipers = array(
					"A12345" =>
						array(
						"nama" => "Haq",
						"Jab" => "TSM"
						
					),
					
					"G112345" =>	
					array(      
						"nama" => "Zaini",
           				"Jab" => "TSM"
						)
					);
echo "<br />";
//or can write like this

$multipers ["A12345"]["nama"] = "Haq";
$multipers ["A12345"]["Jab"] = "TSM";

$multipers ["G112345"]["nama"] = "Zaini";
$multipers ["G112345"]["Jab"] = "TSM";

print_r($multipers);




				
?>