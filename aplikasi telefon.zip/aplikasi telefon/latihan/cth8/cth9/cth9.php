?php>
$multipers ["Haq"]["Bah"] = "Haq";
$multipers ["Haq"]["Jab"] = "TSM";

$multipers ["Zaini"]["Bah"] = "Zaini";
$multipers ["Zaini"]["Jab"] = "TSM";

?>