<?php
  function add($x,$y) {
     $total = $x * $y;
     return $total;
  }

  $x = 1;
  $y = 16;
  echo '$x = ' . $x . "<br>";
  echo '$y = ' . $y . "<br>";
  echo '$x X $y = ' . add($x,$y);
?>

