<?php
  function writeMyName($fname,$punctuation) {
    echo $fname . " Ramli ".$punctuation."<br>";
  }

  echo "My name is ";
  writeMyName("Mohamad","?");

  echo "My name is ";
  writeMyName("Hassan","!");

  echo "My name is ";
  writeMyName("Jamaludin","...");
?>
