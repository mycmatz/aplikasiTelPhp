<?php
  $array1 = array("img1.png", "img4.png", "img3.png", "img44.png", "img11.png",  "img25.png", "img2.png");
  echo "********** Before any sorting **********<br><br>";
  foreach ($array1 as $key => $val) {
     echo "array1[" . $key . "] = " . $val . "<br>";
  }
  sort($array1);
  echo "<br><br>********** Using Standard sorting ********** sort <br><br>";
  foreach ($array1 as $key => $val) {
     echo "array1[" . $key . "] = " . $val . "<br>";
  }
  natsort($array1);
  echo "<br><br>********** Using Natural order sorting ********** natsort <br><br>";
  foreach ($array1 as $key => $val) {
     echo "fruits[" . $key . "] = " . $val . "<br>";
  }
?> 
