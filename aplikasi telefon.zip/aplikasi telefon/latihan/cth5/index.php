<?php
$x = TRUE;
$y = TRUE;

if( $x && $y)

{
	echo 'TRUE';
	
}else
{
 echo 'FALSE';
}

echo "<br />"

?>
<?php
$x = TRUE;
$y = FALSE;

if( $x && $y)

{
	echo 'TRUE';
	
}else
{
 echo 'FALSE';
}


echo "<br />"
?>
<?php
$x = FALSE;
$y = FALSE;

if( $x && $y)

{
	echo 'TRUE';
	
}else
{
 echo 'FALSE';
}

echo "<br />"


?>

<?php
echo "<br />"
?>



<?php

$x = TRUE;
$y = TRUE;

if( $x || $y)

{
	echo 'TRUE';
	
}else
{
 echo 'FALSE';
}

echo "<br />"

?>
<?php
$x = TRUE;
$y = FALSE;

if( $x || $y)

{
	echo 'TRUE';
	
}else
{
 echo 'FALSE';
}


echo "<br />"
?>
<?php
$x = FALSE;
$y = FALSE;

if( $x || $y)

{
	echo 'TRUE';
	
}else
{
 echo 'FALSE';
}

echo "<br />"

?>