<?php 
  $i=1;
  while($i<=5) {
    echo "The number is " . $i . "<br />";
    $i++;
  }
?>
