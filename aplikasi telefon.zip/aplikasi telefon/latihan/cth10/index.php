<?php
   
  $fruits = array("d" => "lemon", 
				 "a" => "orange",
				 "b" => "banana", 
				 "c" => "apple");
  print_r($fruits);
  echo "<center>";
 
  
  echo "<br>";
  echo "<br>*********Before asort *********<br><br>";
  foreach ($fruits as $key => $val) {
     echo 'fruits[" '. $key .' "] = ' . $val . "<br>";
  }
   asort($fruits);
  echo "<br>*********After asort *********<br><br>";
  foreach ($fruits as $key => $val) {
     echo 'fruits[" '. $key .' "] = ' . $val . "<br>";
  }
  echo "<br>";
  print_r($fruits);
?> 

<?php
   
  $fruits = array("1" => "lemon", 
				 "3" => "orange",
				 "2" => "banana", 
				 "0" => "apple");
  print_r($fruits);
  echo "<center>";

  
  echo "<br>";
  echo "<br>*********Before asort *********<br><br>";
  foreach ($fruits as $key => $val) {
     echo 'fruits[" '. $key .' "] = ' . $val . "<br>";
  }
   asort($fruits);
  echo "<br>*********After asort *********<br><br>";
  foreach ($fruits as $key => $val) {
     echo 'fruits[" '. $key .' "] = ' . $val . "<br>";
  }
  echo "<br>";
  print_r($fruits);
?> 