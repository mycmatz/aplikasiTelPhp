<?php

$multipers ["Haq"]["Bah"] = "TSM";
$multipers ["Haq"]["Jab"] = "StaRT";

$multipers ["Zaini"]["Bah"] = "TechAD";
$multipers ["Zaini"]["Jab"] = "StaRT";

//cth print bahagian
//echo $multipers ["Zaini"]["Bah"];

/***


Haq dan Zaini bertugas di Jabatan StaRT.
Haq dari Bah. TSM, dan Zaini dari Bah. TechAD

***/
echo "<big />";
echo "<big />";
echo "<big />";
echo "<big />";
echo "<big />";
echo "<big />";
echo "<big />";
echo "<big />";
echo "<big />";
echo "<big />";
echo "<big />";
echo "<br />";
echo "<center />";
echo " Haq dan Zaini bertugas di Jab ". $multipers ['Haq']['Jab'] .
	  " Haq dari Bah." . $multipers ['Haq']['Bah'].
	  ", dan Zaini dari Bah." . $multipers ['Zaini']['Bah'] ;






?>