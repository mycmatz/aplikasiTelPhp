<?php
$email = "mycmatz@outlook.com";
$domain = strstr ($email, "@");
echo "<center />";
echo "Email:". $email;
echo "<br/>";

echo "Domain:". $domain;





?>