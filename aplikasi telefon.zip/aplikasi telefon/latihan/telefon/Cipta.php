
<?php

include('header.php');
include('menu.php');
?>

<h2>Borang Cipta</h2>

<form action="insert_new.php" method="post">
Nama : <input type="text" name="inputnama" />
<br>
<br>
Bhgn : <input type="text" name="inputbhgn" />
<br>
<br>
Telefon : <input type="text" name="inputphone" />
<br>
<br>
Email : <input type="text" name="inputemail" />
<br>
<br>

<input type="submit" value="Hantar" />
</form>


<?php
include ('footer.php');

?>