<?php
include ('header.php');
include ('menu.php');

?>
<!--
<pre>
<?php

//print_r($_POST);

?>
</pre>
--!>

<?php

if ($_POST['inputnama'] == '' || $_POST['inputbhgn'] == '' ||
    $_POST['inputphone'] == ''|| $_POST['inputemail'] == '')
	{
	echo "Sila isi semua maklumat. Tekan Button Back";
	exit();
}
//convert symbol to html code for security
$inputid = htmlentities($_POST ['inputid']);
$inputnama = htmlentities($_POST ['inputnama']);
$inputbhgn = htmlentities($_POST ['inputbhgn']);
$inputphone = htmlentities($_POST ['inputphone']);
$inputemail = htmlentities($_POST ['inputemail']);

//connect db_host
	include ('conn.php');
	
  //insert
  $sql="UPDATE `person` 
SET 
	`Nama`='$inputnama',
	`phone`='$inputphone',
	`email`='$inputemail',
	`bhgn`= '$inputbhgn'
WHERE 
	`id`='$inputid'
	";

  if (!mysql_query($sql,$conn)) {
    die('Error: ' . mysql_error());
  }else{
    echo "<br>1 Rekod telah di kemaskini <br>";
	echo 'Kembali ke <a href="index.php">senarai.</a>';
  }
  //remember to close connection
  mysql_close($conn);
 
  include ('footer.php');
  
?>