<?php
//print_r($_POST);

//convert to htmlcodes
$del_id = htmlentities ($_POST ['del_id']);

//include mysql 
include('conn.php');
//sql command to delete file
$sql = "DELETE FROM person WHERE id=$del_id";
$result = mysql_query ($sql,$conn) or die (mysql_error());
$aff_rows = mysql_affected_rows ();

//papar mesej 
if($aff_rows > 0) {
	echo '1 rekod telah hapus.';
	
} else{
	echo 'Tiada rekod di hapus.';
}
//pautan ke senarai rekod
echo '<br />Kembali ke <a href="index.php">senarai.</a>';

?>