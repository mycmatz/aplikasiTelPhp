<p>
<a class="menu "href="index.php">Page Utama</a>
<a class="menu" href="cipta.php">Cipta</a>

</p>