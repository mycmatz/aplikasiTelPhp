
<?php
if(isset($_GET ['id'])){
if($_GET ['id'] ==""){
	echo "Tiada Maklumat ID. Sila Kembali ke <a href=\"index.php\'>senarai</a>.";
	exit();
 }
}else{
	echo "Tiada Maklumat ID. Sila Kembali ke <a href=\"index.php\'>senarai</a>.";
	exit();
}

include('header.php');
include('menu.php');

include('conn.php');
$sql = "SELECT * FROM person WHERE id=" . $_GET ['id'];
$result = mysql_query ($sql,$conn) or die (mysql_error () );
$row = mysql_fetch_assoc($result);
?>

<h2>Borang Pinda</h2>

<form action="pindaproc.php" method="post">
<input type="hidden" name="inputid" value="<?php echo $row['id']?>"/>
Nama : <input type="text" name="inputnama" value="<?php echo $row['Nama']?>" />
<br>
<br>
Bhgn : <input type="text" name="inputbhgn" value="<?php echo $row['bhgn']?>"/>
<br>
<br>
Telefon : <input type="text" name="inputphone" value="<?php echo $row['phone']?>"/>
<br>
<br>
Email : <input type="text" name="inputemail" value="<?php echo $row['email']?>"/>
<br>
<br>

<input type="submit" value="Hantar" />
</form>


<?php
include ('footer.php');

?>