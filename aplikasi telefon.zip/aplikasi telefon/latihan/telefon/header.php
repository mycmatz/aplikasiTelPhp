<html>
<head>
	<title>Buku Telefon</title>
	<link rel="stylesheet" type="text/css" href="style.css" media="all">
</head>

<body>

<h1>Buku Telefon</h1>

