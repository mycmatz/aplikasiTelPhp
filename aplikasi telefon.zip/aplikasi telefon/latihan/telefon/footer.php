<div class="footer">
&copy;2015<a>Dibangunkan oleh: Ahmad Zaini</a>

</div
</body>
</html>