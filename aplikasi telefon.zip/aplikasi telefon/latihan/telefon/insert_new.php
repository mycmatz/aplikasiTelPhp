<?php
include ('header.php');
include ('menu.php');

?>
<!--
<pre>
<?php

//print_r($_POST);

?>
</pre>
-->

<?php

if ($_POST['inputnama'] == '' || $_POST['inputbhgn'] == '' ||
    $_POST['inputphone'] == ''|| $_POST['inputemail'] == ''){
	echo "Sila isi semua maklumat. Tekan Button Back";
	exit();
}
//convert transaction for security
$inputnama = htmlentities($_POST ['inputnama']);
$inputbhgn = htmlentities($_POST ['inputbhgn']);
$inputphone = htmlentities($_POST ['inputphone']);
$inputemail = htmlentities($_POST ['inputemail']);

//connect db_host
	include ('conn.php');
	
  //insert
  $sql="INSERT INTO `person`(`id`, `Nama`, `phone`, `email`, `bhgn`) 
		VALUES (null,'$inputnama','$inputphone','$inputemail','$inputbhgn')";
  
  if (!mysql_query($sql,$conn)) {
    die('Error: ' . mysql_error());
  }else{
    echo "<br>1 Rekod telah ditambah <br>";
	echo '<a href="cipta.php">Klik untuk Tambah.</a>';
  }
  //remember to close connection
  mysql_close($conn);
 
  include ('footer.php');
  
?>