<?php

$t = " nama ";
echo $t;
echo '<br />';

$t = trim( $_POST['inputnama']);
echo $t;


?>