
<?php 
	$txt="Welcome To Mariman Lab";
    

	
	echo "<center />";
	echo "<big />";
	
	echo $txt;
	
	echo "<br />";
	
	
	echo "<center />";
	$txt1="Selamat Datang KeKursus PHP";
	echo $txt1;



echo "<br />";

echo "<br />";
   $txt1="Hello World!";
   $txt2="My name is";
   $txt3="Ahmad zaini";

   $txt4 = $txt . "" . $txt1 . " " . $txt2 . " " . $txt3;
	
echo $txt4;
echo "<br />";
echo 'strlen of variables $txt4 is = '.strlen($txt4);


   
?>


<?php
   $txt1="Hello";
   $txt2="to";
   $txt3="me";
   $txt4=$txt1 . " " . $txt2 . " " . $txt3;
   echo '$txt2 =  '.$txt2 . "<br>";
   echo '$txt4 =  '.$txt4 . "<br>";
   echo 'strpos($txt4, $txt2) 4 is = '.strpos($txt4, $txt2)."<br>";
   echo 'strpos($txt4, o) 4 is = '.strpos($txt4, "o");
?>

<?php
$email = "mycmatz@outlook.com";
$domain=strstr ($email, "@");

echo "Email:". $email;
echo "<br/>";

echo "Domain:". $domain;





<?