<?php
//operator

$x = "a";
$y = 0;

echo $x;
echo "<br />";

echo $y;
echo "<br />";

$x = $y;

echo $x;

$x = 1;
$y = 2;

//$z = $x + $y;

//$x += $y;

//$x = $x - $y;
//$x *= $y;

$x %= $y;

echo $x;



?>