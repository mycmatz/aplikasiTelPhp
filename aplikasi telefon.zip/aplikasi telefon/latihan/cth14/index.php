<?php
   $i=1;
   $totalloop = 10;
  while($i<=$totalloop) {
    echo "The number is " . $i . "<br />";
    $i++;
    echo "after adding 1 to x, x = " . $i . "<br>";
    if ($i <= $totalloop){
	echo "Condition still true <br><br>";
    }else {
	echo "Condition false and while loop end";
    }
  }
  echo "<br><br>*************************************************<br><br>";
  echo 'while($i<='.$totalloop.') { <br>';
  echo 'The number is $i' . "<br />";
  echo '$i++;';
  echo "<br> }";
?> 
