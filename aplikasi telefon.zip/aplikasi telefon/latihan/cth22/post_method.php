


<html>
<body>

Welcome <?php echo $_POST["inputname"]; ?>.
<br/>
You are <?php echo $_POST["inputage"]; ?> years old.

</body>
</html>


