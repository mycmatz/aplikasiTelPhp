<html>
<center>
<head>
</head>
<div>
EPF CALCULATION</div>
<body bgcolor ="cyan">
<br />
<hr />
<form action="kira_epf.php" method="post">
<h2>Salary: <input type="text" name="salary" /></h2>

<input type="submit" value="Hantar"/>
</form>
</body>
</center>
</html>
