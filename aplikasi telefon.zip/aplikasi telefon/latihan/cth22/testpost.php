<html>
<body>
<form action="post_method.php" method="post">
Name: <input type="text" name="inputname" />
Age: <input type="text" name="inputage" />
<input type="submit" value="Hantar"/>
</form>
</body>
</html>
