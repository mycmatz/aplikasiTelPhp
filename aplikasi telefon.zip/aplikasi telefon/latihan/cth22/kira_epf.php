<html>
<head>

</head>
<center><div><h3>Contribution</h3></div>
<body bgcolor="silver">
<hr/>
<div>
<h4>
<?php

//check 
if( $_POST ['salary'] == ""){
	echo "Sila Masukkan Jumlah Gaji. Sila tekan Back.";
}
else {
	//Employee Contribution
	//$empl_contrib = $_POST ['salary']*(11/100);
	$empl_contrib = kira_contrib($_POST ['salary'], 11);
	
	//$emplr_contrib = $_POST ['salary']*(12/100);
	$emplr_contrib = kira_contrib( $_POST ['salary'], 12);
	//without function kira_contrib
	//$Total_contrib = $empl_contrib + $emplr_contrib;
	echo "<big />";
	echo "<big />";
	echo "<center />";
	
	echo "EPF Calculation";
	echo "Employee's 11% Contrib. = RM". $empl_contrib;
	echo "<br />";
	echo "Employer 12% Contrib. = RM". $emplr_contrib;
	echo "<br />";
	//Total Contribution 
	//echo "Total Contribution = RM". $Total_contrib;
	echo "Total Contrib = RM" . ($empl_contrib + $emplr_contrib);
}
function kira_contrib ($salary, $percent){
	$contrib = $salary * ($percent / 100);
	return $contrib;
}

?>
</h4>
</div>
</center>
</body>
</html>