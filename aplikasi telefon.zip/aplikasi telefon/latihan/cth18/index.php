<?php

  function cetaNamasaya() {
    echo "Ahmad Zaini";
  }
function noBadanSaya() {
    echo "RF 149074";
  }
  
  
  echo "Nama Saya ialah ";
  cetaNamasaya();
  echo ".<br>That's right, ";
  cetaNamasaya();
  echo " is my name.";
 echo "<br />";
  echo "Nombor badan Saya ialah ";
  noBadanSaya();
  echo ".<br>Betul, ";
  noBadanSaya();
  echo " adalah nombor badan saya.";
  echo "<br />";

 ?>
 
 <?php
  
 function writeMyName($fname) {
    echo $fname . " Ramli.<br />";
  }
  echo "My name is ";
  writeMyName("Mohamad");

  echo "My name is ";
  writeMyName("Hassan");

  echo "My name is ";
  writeMyName("Jamaludin");
?>



