<?php
	$huruf_pangkat = "G";

	switch ($huruf_pangkat) {
	case "G":
	echo "G : Uniform";
	break;
	
	case "I":
	echo "I : Uniform";
	break;

	case "A":
	echo "A : Awam";
	break;
	
	default:
	echo "Tiada dalam rekod";
	}

?>