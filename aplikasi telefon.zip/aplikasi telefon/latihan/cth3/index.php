<?php
$email = "mycmatz@gmail.com";
$nama = substr ($email, 0,4);

echo "Nama:". $nama;
echo "<br/>";







?>