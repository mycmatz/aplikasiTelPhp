<?php
$huruf_pangkat = "G";

if ($huruf_pangkat == "G" || $huruf_pangkat == "I") {

	echo "G : Uniform";
	
   }	else {
        echo "A : Awam";
   }




?>
<?php
$huruf_pangkat = "G";

if ($huruf_pangkat == "G" || $huruf_pangkat == "I") {

	echo "G / I: Uniform";
	
   }	else {
        echo "A : Awam";
   }




?>
<?php
$huruf_pangkat = "G";

if ($huruf_pangkat == "G" || $huruf_pangkat == "I") {

	echo "G / I: Uniform";
	
   }	elseif ($huruf_pangkat == "A"){
        echo "A : Awam";
   }
else {
	echo "Tiada dalam rekod.";
}


?>