<?php
  $fruits = array("d" => "lemon", "a" => "orange", "b" => "banana", "c" => "apple");
  print_r($fruits);
  echo "<br>";
  echo "<br>*********Before asort *********<br><br>";
  foreach ($fruits as $key => $val) {
     echo 'fruits[" '. $key .' "] = ' . $val . "<br>";
  }
   asort($fruits);
  echo "<br>*********After asort *********<br><br>";
  foreach ($fruits as $key => $val) {
     echo 'fruits[" '. $key .' "] = ' . $val . "<br>";
  }
  echo "<br>";
  print_r($fruits);
?> 
