<?php
  $arr=array("one", "two", "three");

  foreach ($arr as $num=>$fff) {
    echo "ID Key: " . $num . " - - - ";
    echo "Value: " . $fff . "<br>";
    echo "******************************<br>";
  }
  echo "<br>";
  foreach ($arr as $key => $val) {
     echo "arr[" . $key . "] = " . $val . "<br>";
  }
?>
