<html>
<body>

Welcome <?php echo $_REQUEST["inputname"]; ?>.
<br>
You are <?php echo $_REQUEST["inputage"]; ?> years old.
<br>
You are from <?php echo $_REQUEST["inputcity"]; ?> 
</body>
</html>
