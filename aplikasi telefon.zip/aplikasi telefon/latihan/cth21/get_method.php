<html>
<body>

Welcome <?php echo $_GET["inputname"]; ?>.
<br>
You are <?php echo $_GET["inputage"]; ?> years old.
<br>
You are from <?php echo $_GET["inputcity"]; ?> 
</body>
</html>
