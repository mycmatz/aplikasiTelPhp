<html>
<body>
<form action="get_method.php" method="get">
Name: <input type="text" name="inputname" />
<br />
Age: <input type="text" name="inputage" />
<br />
City: <input type="text" name="inputcity" />
<br />
<input type="submit" value="Hantar"/>
</form>
</body>
</html>
