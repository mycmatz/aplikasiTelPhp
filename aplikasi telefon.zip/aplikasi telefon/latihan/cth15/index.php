<?php 
  $i=0;
  $totalloop = 6;
  do {
    $i++;
    echo "The number is " . $i . "<br />";
   } while ($i<$totalloop);
   echo "<br />";
?>

<?php 
  $i=0;
  $totalloop = 3;
  do {
    $i++;
    echo "The number is " . $i . "<br />";
   } while ($i<$totalloop);
?>
