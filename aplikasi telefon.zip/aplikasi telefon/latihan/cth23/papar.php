<?php
//papar.php
//connect to db
include('conn.php');
?>
<table border="1">
	</tr>
	<th>Bil.</th>
	<th>Nama</th>
	<th>Umur</th>
	</tr>
<?php
//query
$sql = "SELECT * FROM person";
$result = mysql_query ($sql,$conn) or die (mysql_error ());
$i=1;
//mysql_fetch _array akan ambik result
while($row = mysql_fetch_array($result)) {
   echo "<tr>";
   echo "<td>$i.</td>";
   echo "<td>$row[Nama]&nbsp;</td>";
   echo "<td>$row[age]&nbsp</td>";
   echo "</tr>";
   $i++;
	
  }










?>