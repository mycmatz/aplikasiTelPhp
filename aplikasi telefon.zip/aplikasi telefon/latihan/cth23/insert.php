
<html>
<body>
<?php
	//connect db_host
	include ('conn.php');
	
  
  // select a database
  $sql="INSERT INTO person (id, nama, age)    
  VALUES( null,'$_POST[inputnama]','$_POST[inputumur]')";
  if (!mysql_query($sql,$conn)) {
    die('Error: ' . mysql_error());
  }else{
    echo "1 record added <br>";
  }
  // remember to close connection
?>
  <form>
  <input type="button" value="Tambah Lagi" onclick="window.location.href = 'mysql1.php'">
  </form>
  <br>
</body>
</html>

