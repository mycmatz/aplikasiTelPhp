<html>
<body>

<form action="insert.php" method="post">
Nama : <input type="text" name="inputnama" />
<br>
Umur : <input type="text" name="inputumur" />
<br>

<input type="submit" value="Hantar" />
</form>

</body>
</html>
